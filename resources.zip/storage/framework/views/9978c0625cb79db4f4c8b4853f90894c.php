<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-blue-700 leading-tight">
            <?php echo e(__('Dashboard Kualitas Air')); ?>

        </h2>
        <button class="text-white bg-blue-600 px-3 my-1 rounded-md py-1">Refresh</button>
     <?php $__env->endSlot(); ?>

    <div class="bg-blue-50 px-2 md:px-4 lg:px-6 min-h-screen" x-data="dashboard()" x-init="init()">
        

        <!-- Sensor Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
            
            <?php $__currentLoopData = $sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="p-4 rounded-2xl shadow bg-white flex items-center gap-2 border-l-4
                    <?php if($sensor['status'] === 'normal'): ?> border-blue-500
                    <?php elseif($sensor['status'] === 'warning'): ?> border-yellow-400
                    <?php else: ?> border-red-500 <?php endif; ?>">
                    <i data-lucide="<?php echo e($sensor['icon']); ?>"
                        class="w-6 h-6
                        <?php if($sensor['status'] === 'normal'): ?> text-blue-600
                        <?php elseif($sensor['status'] === 'warning'): ?> text-yellow-500
                        <?php else: ?> text-red-600 <?php endif; ?>"></i>
                    <div class="">
                        <div class="font-medium text-gray-800 text-sm"><?php echo e($sensor['label']); ?></div>
                        <div class="text-lg font-semibold
                            <?php if($sensor['status'] === 'normal'): ?> text-blue-600
                            <?php elseif($sensor['status'] === 'warning'): ?> text-yellow-500
                            <?php else: ?> text-red-600 <?php endif; ?>"
                        ><?php echo e($sensor['value']); ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Chart -->
        <!-- Populasi & Status Perangkat -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">

            <!-- Kartu Populasi Lobster -->
            <div class="bg-white p-5 rounded-2xl shadow-md">
                <div class="flex items-center gap-2 mb-3">
                    <i data-lucide="fish" class="w-5 h-5 text-blue-600"></i>
                    <h2 class="text-lg font-semibold text-blue-600">Populasi Lobster</h2>
                </div>

                <div class="text-3xl font-bold text-blue-700" x-text="132"></div>
                <p class="text-gray-500 mb-3">Estimasi Biomassa: <span x-text="'1.7 kg'"></span></p>

                <div class="h-24">
                    <canvas id="biomassChart"></canvas>
                </div>
            </div>

            <!-- Kartu Status Perangkat -->
            <div class="bg-white p-5 rounded-2xl shadow-md">
                <h2 class="text-lg font-semibold text-blue-600 mb-4">Status Perangkat</h2>

                

                <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex justify-between items-center px-3 py-2 border rounded-xl mb-2 bg-gray-50">
                        <span class="font-medium text-gray-800"><?php echo e($device['name']); ?></span>
                        <span class="px-3 py-1 text-xs font-semibold rounded-full
                            <?php if($device['status'] === "ON"): ?> bg-blue-100 text-blue-700
                            <?php elseif($device['status'] === "OFF"): ?> bg-gray-200 text-gray-500
                            <?php endif; ?>"
                        ><?php echo e($device['status']); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <a href="/control"
                    class="block text-center w-full bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg py-2 mt-3">
                    Kontrol Manual
                </a>
            </div>
        </div>

        <!-- Notifikasi -->
        <div class="bg-white p-5 rounded-2xl shadow-md">
            <div class="flex items-center gap-2 mb-3">
                <i data-lucide="alert-triangle" class="text-yellow-500 w-5 h-5"></i>
                <h2 class="text-lg font-semibold text-blue-700">Notifikasi Terbaru</h2>
            </div>
            <template x-if="alerts.length === 0">
                <p class="text-gray-500">Tidak ada notifikasi aktif.</p>
            </template>
            <ul>
                <template x-for="alert in alerts" :key="alert.id">
                    <li class="border rounded-xl p-3 mb-2 flex justify-between bg-blue-50">
                        <span class="text-blue-700 font-medium" x-text="alert.message"></span>
                        <span class="text-sm text-gray-500" x-text="alert.time"></span>
                    </li>
                </template>
            </ul>
        </div>

        <!-- Data History -->
        <div class="bg-white shadow-md rounded-2xl p-5 mt-6">
            <div class="flex flex-col sm:flex-row justify-between gap-3 mb-4">
                <h2 class="text-xl font-semibold text-blue-700 flex items-center gap-2">
                    <i data-lucide="calendar" class="w-5 h-5"></i> Riwayat Data Sensor
                </h2>
                <div class="flex gap-2">
                    <select x-model="filter"
                        class="max-sm:flex-1 border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-400">
                        <option value="daily">Harian</option>
                        <option value="weekly">Mingguan</option>
                        <option value="monthly">Bulanan</option>
                    </select>
                    <button @click="handleExport()"
                        class="max-sm:flex-1 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg flex items-center gap-2">
                        <i data-lucide="download" class="w-4 h-4"></i> Export Excel
                    </button>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full text-sm border border-gray-200 rounded-xl">
                    <thead class="bg-blue-600 text-white">
                        <tr>
                            <th class="py-2 px-4 text-left">Tanggal</th>
                            <th class="py-2 px-4 text-left">Suhu (°C)</th>
                            <th class="py-2 px-4 text-left">DO (mg/L)</th>
                            <th class="py-2 px-4 text-left">pH</th>
                            <th class="py-2 px-4 text-left">Amonia (mg/L)</th>
                            <th class="py-2 px-4 text-left">Kekeruhan (NTU)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="(row, index) in dataHistory" :key="index">
                            <tr class="even:bg-blue-50">
                                <td class="py-2 px-4 font-medium text-gray-800" x-text="row.date"></td>
                                <td class="py-2 px-4 text-gray-700" x-text="row.temperature"></td>
                                <td class="py-2 px-4 text-gray-700" x-text="row.DO"></td>
                                <td class="py-2 px-4 text-gray-700" x-text="row.pH"></td>
                                <td class="py-2 px-4 text-gray-700" x-text="row.ammonia"></td>
                                <td class="py-2 px-4 text-gray-700" x-text="row.turbidity"></td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\iot-lobster\resources\views/dashboard.blade.php ENDPATH**/ ?>