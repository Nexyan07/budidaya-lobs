<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>IoT Lobster Dashboard</title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-blue-50 text-gray-900">
  <?php echo e($slot); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\iot-lobster\resources\views/app.blade.php ENDPATH**/ ?>